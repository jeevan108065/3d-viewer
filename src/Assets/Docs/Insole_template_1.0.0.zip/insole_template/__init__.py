# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Insole template",
    "author" : "Rombus", 
    "description" : "",
    "blender" : (4, 2, 0),
    "version" : (1, 0, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import os


addon_keymaps = {}
_icons = None


def sna_update_sna_flare_A6894(self, context):
    sna_updated_prop = self.sna_flare
    bpy.data.node_groups['SMOOTH'].nodes['Math.002'].inputs[1].default_value = sna_updated_prop


def sna_update_sna_thikness_E3156(self, context):
    sna_updated_prop = self.sna_thikness
    bpy.data.node_groups['SMOOTH'].nodes['Value'].outputs[0].default_value = sna_updated_prop


def sna_update_sna_heel_height_2AF38(self, context):
    sna_updated_prop = self.sna_heel_height
    bpy.data.node_groups['SMOOTH'].nodes['Map Range.003'].inputs[3].default_value = sna_updated_prop


class SNA_PT_INSOLE_7F7F9(bpy.types.Panel):
    bl_label = 'Insole'
    bl_idname = 'SNA_PT_INSOLE_7F7F9'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Insole'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        op = layout.operator('sna.import_3214c', text='Bring in STL', icon_value=0, emboss=True, depress=False)
        op = layout.operator('sna.create_24641', text='Create', icon_value=0, emboss=True, depress=False)
        layout.prop(bpy.context.scene, 'sna_flare', text='Edge Flare', icon_value=0, emboss=True)
        layout.prop(bpy.context.scene, 'sna_thikness', text='Thickness', icon_value=0, emboss=True)
        layout.prop(bpy.context.scene, 'sna_heel_height', text='Heel height', icon_value=0, emboss=True)


class SNA_OT_Create_24641(bpy.types.Operator):
    bl_idname = "sna.create_24641"
    bl_label = "Create"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        before_data = list(bpy.data.node_groups)
        bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'Insole CAD- Horseshoe_Dot pattern.blend') + r'\NodeTree', filename='SMOOTH', link=False)
        new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
        appended_E0A9F = None if not new_data else new_data[0]
        bpy.ops.object.select_all('INVOKE_DEFAULT', action='SELECT')
        bpy.context.view_layer.objects.active = bpy.context.view_layer.objects.selected[0]
        modifier_AE545 = bpy.context.active_object.modifiers.new(name='INS', type='NODES', )
        bpy.context.active_object.modifiers['INS'].node_group = bpy.data.node_groups['SMOOTH']
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Import_3214C(bpy.types.Operator):
    bl_idname = "sna.import_3214c"
    bl_label = "Import"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.object.select_all(action='SELECT')
        bpy.ops.object.delete(use_global=True, confirm=True)
        bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
        before_data = list(bpy.data.objects)
        bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'Insole CAD- Horseshoe_Dot pattern.blend') + r'\Object', filename='Insole', link=False)
        new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
        appended_6AD76 = None if not new_data else new_data[0]
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_flare = bpy.props.FloatProperty(name='Flare', description='', default=1.0, subtype='NONE', unit='NONE', min=0.5, max=3.0, step=3, precision=3, update=sna_update_sna_flare_A6894)
    bpy.types.Scene.sna_thikness = bpy.props.FloatProperty(name='Thikness', description='', default=2.0, subtype='NONE', unit='NONE', min=1.5, max=4.0, step=3, precision=3, update=sna_update_sna_thikness_E3156)
    bpy.types.Scene.sna_heel_height = bpy.props.FloatProperty(name='Heel Height', description='', default=0.0, subtype='NONE', unit='NONE', min=0.0, max=8.0, step=3, precision=3, update=sna_update_sna_heel_height_2AF38)
    bpy.utils.register_class(SNA_PT_INSOLE_7F7F9)
    bpy.utils.register_class(SNA_OT_Create_24641)
    bpy.utils.register_class(SNA_OT_Import_3214C)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_heel_height
    del bpy.types.Scene.sna_thikness
    del bpy.types.Scene.sna_flare
    bpy.utils.unregister_class(SNA_PT_INSOLE_7F7F9)
    bpy.utils.unregister_class(SNA_OT_Create_24641)
    bpy.utils.unregister_class(SNA_OT_Import_3214C)
